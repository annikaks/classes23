import { NumberSet } from "./number_set";
import { List, compact_list, explode_array } from './list';

/**
 * Updates vals1 to not contain any of the numbers in vals2. Both arrays are
 * assumed to be sorted and contain only distinct numbers.
 * @param vals1 the first sorted array of distinct integers
 * @param vals2 the second sorted array of distinct integers
 * @modifies vals1
 * @effects vals1 = without(vals1_0, vals2)
 */
export function removeAll(vals1: number[], vals2: number[]): void {
  let i: number = 0;
  let j: number = 0;
  let k: number = 0;

  // Inv: vals1[0 .. k-1] = without(vals1_0[0 .. i-1], vals2) and
  //      vals1[k .. n-1] = vals1_0[k .. n-1] and
  //      vals2[j-1] < vals1[i] (if these indexes exist)
  while (i !== vals1.length) {
    if ((j === vals2.length) || (vals1[i] < vals2[j])) {
      vals1[k] = vals1[i];
      i = i + 1;
      k = k + 1;
    } else if (vals1[i] > vals2[j]) {
      j = j + 1;
    } else {
      i = i + 1;
      j = j + 1;
    }
  }

  // Inv: vals1[0 .. k-1] = without(vals1_0, vals2)
  while (vals1.length !== k)
    vals1.pop();
}

/**
 * Updates vals1 to contain all of the numbers in vals2. Both arrays are assumed
 * to be sorted and contain only distinct numbers.
 * @param vals1 the first sorted array of distinct integers
 * @param vals2 the second sorted array of distinct integers
 * @modifies vals1
 * @effects vals1 = with(vals1_0, vals2)
 */
export function addAll(vals1: number[], vals2: number[]): void {
  let i: number = 0;
  let j: number = 0;

  const vals3: number[] = [];

  // Inv: vals3 = with(vals1[0 .. i-1], vals2) and
  //      vals2[j-1] < vals1[i] (if these indexes exist)
  while (i !== vals1.length || (j !== vals2.length)) {
    if ((j === vals2.length) || (vals1[i] < vals2[j])) {
      vals3.push(vals1[i]);
      i = i + 1;
    } else if ((i === vals1.length) || vals1[i] > vals2[j]) {
      vals3.push(vals2[j]);
      j = j + 1;
    } else {
      vals3.push(vals1[i]);
      i = i + 1;
      j = j + 1;
    }
  }

  // Now have vals3 = with(vals1_0, vals2)
  if (vals3.length < vals1.length)
    throw new Error('impossible');

  // Inv: vals1[0 .. k-1] = vals3[0 .. k-1]
  for (let k = 0; k < vals1.length; k++)
    vals1[k] = vals3[k];

  // Inv: vals1[0 .. vals1.length-1] = vals3[0 .. vals1.length-1]
  while (vals1.length !== vals3.length)
    vals1.push(vals3[vals1.length]);
}

function getNumbers(set: number[], a: number, b:number, comp: boolean): List<number> {
  if(!comp){
    return explode_array(set);
  }
  let complement : number[] = [];
  let i : number = 0;

  // iterate through the range of numbers we were given and add the current number to 
  //  a new set if they are not included in the original set. Everything
  //  that is >= a and < set[i] has already been checked and added to the complement
  while(a <= b){
    if(a < set[i]){
      complement.push(a);
      a++;
    } else if(a > set[i] || i === set.length){
      complement.push(a);
      a++
    } else{
      a++;
      i++
    }
  }

  return explode_array(complement);
}


/**
 * Removes any duplicate elements from the given sorted array of numbers.
 * @param L a sorted array of numbers
 * @modifies L
 * @effects L[0] < L[1] < ... < L[L.length-1] and
 *     contains(L, x) = contains(L_0, x) for any x
 */
export function uniquify(L: number[]): void {
  if (L.length === 0)
    return;
  
  let i = 1;
  let k = 1;

  // Inv: L[0 .. k-1] = uniquify(L_0[0 .. i-1]) and
  //      L[k .. n-1] = L_0[k .. n-1] and
  //      L[i-1] = L[k-1]
  while (i !== L.length) {
    if(L[i] > L[i - 1]){
      L[k] = L[i]
      k++
      i++
    } else if(L[i] === L[i - 1]){
      i++
    } else{
      return
    }

    // i = i + 1;  // TODO (3a): replace this with correct code
    // k = k + 1;  // TODO (3a): replace this with correct code
  }

  // TODO (3a): implement the rest
  while(i > k){
    L.pop();
    i--;
  }
}


// TODO (3b): add class SortedNumberSet
class SortedNumberSet implements NumberSet{
  arr : number[];
  comp: boolean;
  // AF: the object is a set of numbers that are included in the set when comp is 
  //    false, and the values not included in the set when comp is true
  // RI: numbers   must be <= a and >= b and will be sorted, if comp is true then 
  //    number[] contains all values NOT in set. 

  constructor(arr: number[]){
    arr.sort((a, b) => a - b);
    uniquify(arr)
    this.arr = arr;
    this.comp = false
  }

  removeAll(vals2: NumberSet){
    const SNSvals2 = vals2 as SortedNumberSet
    // if (vals2 instanceof SortedNumberSet) {
      if ((this.comp && SNSvals2.comp)){
        removeAll(SNSvals2.arr, this.arr)
        this.arr = SNSvals2.arr
        this.comp = false
      } else if (this.comp && !SNSvals2.comp){
        addAll(this.arr, SNSvals2.arr)
        this.comp = true
      } else if(!this.comp && SNSvals2.comp){
        const temp = makeSortedNumberSet(explode_array(this.arr))
        removeAll((temp as SortedNumberSet).arr, SNSvals2.arr)
        removeAll(this.arr, (temp as SortedNumberSet).arr)
      } else{
        removeAll(this.arr, SNSvals2.arr)
      } 
    // }
  }

  addAll(vals2: NumberSet){
    const SNSvals2 = vals2 as SortedNumberSet
    if(this.comp && SNSvals2.comp){
      const temp = makeSortedNumberSet(explode_array(this.arr))
      removeAll((temp as SortedNumberSet).arr, SNSvals2.arr)
      console.log((temp as SortedNumberSet).arr)
      //temp should = [1, 2]
      
      removeAll(this.arr, (temp as SortedNumberSet).arr)
      console.log(this.arr)
      //this.arr should = [3, 4]
      this.comp = true
    } else if(!this.comp && SNSvals2.comp){
      removeAll(SNSvals2.arr, this.arr)
      this.arr = SNSvals2.arr
      this.comp = true
    } else if (this.comp && !SNSvals2.comp){
      removeAll(this.arr, SNSvals2.arr)
      this.comp = true
    }else{
      addAll(this.arr, SNSvals2.arr)
    }
  }

  getNumbers(a: number, b: number): List<number> {
    return getNumbers(this.arr, a, b, this.comp)
  }

  complement(): void {
      this.comp = !this.comp
  }
}


// TODO (3c): add function makeSortedNumberSet
/**
 * Returns a NumberSet with the numbers in the list.
 * @param vals list of numbers to make a SortedNumberSet from
 * @returns a SortedNumberSet with all numvers in vals
 */
export function makeSortedNumberSet(vals: List<number>): NumberSet{
  // const set = new Array()
  
  // while(vals != nil ){
  //   set.push(vals.hd)
  //   vals = vals.tl
  // }
  return new SortedNumberSet(compact_list(vals));
}
